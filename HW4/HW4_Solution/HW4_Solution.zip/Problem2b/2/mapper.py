#!/usr/bin/env python
import sys
import re
for i in sys.stdin:    
    i = i.strip()
    col1,col2 = i.split()
    s = int(col2)
    print( "%s\t%d" % (col1[1:4],s) )


