#!/usr/bin/env python
import sys
col1 = None
tot2 = 0
col2 = 0.0
col3 = 0.0
col4 = 0
col5 = None
tot1 = 0
max2_key = None

for i in sys.stdin:
   i = i.strip()
   this_key, value = i.split("\t", 1)
   value = int(value)
 
   if col1 == this_key:
       tot2 += value
       if value>col2:
		col2=value
   else:
       if col1:
	   col3 = col2*100/tot2
	   if col4<col3:
		col4=col3
		max2_key=col1
       tot2 = value
       col1 = this_key
       col2 = value
	   
if col1 == this_key:
	col3 = float(col2)*100/float(tot2)
	if col4<col3:
		col4=col3
		max2_key=col1

print("The County which is more monolithic in manner is %s"%(max2_key))
