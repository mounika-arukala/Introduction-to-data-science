#!/usr/bin/env python
import sys
import re
s = 1
for i in sys.stdin:    
    i = i.strip()
    co1,col2,col3 = i.split()    
    print( "[%s,%s]\t%d" % (col2,col3,s))


