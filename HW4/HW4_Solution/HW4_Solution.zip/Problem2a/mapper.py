#!/usr/bin/env python

import sys
import re



for line in sys.stdin:
    
    line = line.strip()
    col1,col2,col3 = line.split()
    

    value = 1
    print( "%s\t%d" % (col3, value) )


