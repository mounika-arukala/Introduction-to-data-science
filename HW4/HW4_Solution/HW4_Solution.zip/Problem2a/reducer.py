#!/usr/bin/env python
 
import sys
 
col1 = None
tot1 = 0

key = None
total = 0
for i in sys.stdin:
   i = i.strip()
   col2, value = i.split("\t", 1)
   value = int(value)
 
   if col1 == col2:
       tot1 += value
   else:
       if col1:
           print( "%s\t%d" % (col1, tot1) )
	   if total<tot1 :
	      total=tot1
	      key=col1
       tot1 = value
       col1 = col2
 
if col1 == col2:
   print( "%s\t%d" % (col1, tot1) )
   if total<tot1 :
	      total=tot1
	      key=col1

print("\nMax key is %s and Max value is %d" %(key,total))
