#!/usr/bin/env python 
import sys 
col1 = None
tot1 = 0
col2 = None
col3 = None
tot2 = 0

for i in sys.stdin:
   i = i.strip()
   col4,value = i.split()
   value = int(value) 
   if col1 == col4:
       tot1 += value
   else:
       if col1:
           print( "%s\t%d" % (col1,tot1) )
	   if tot2<tot1 :
	      tot2=tot1
	      col3=col1
       tot1 = value
       col1 = col4
        
if col1 == col4:
   print( "%s\t%d" % (col1,tot1) )
   if tot2<tot1 :
	      tot2=tot1
	      col3=col1

