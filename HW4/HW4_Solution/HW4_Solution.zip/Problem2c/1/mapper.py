#!/usr/bin/env python
import sys
import re
s = 1
for i in sys.stdin:    
    i = i.strip()
    s1,s2,s3 = i.split() 
    print( "[%s,%s]\t%d" % (s3,s2,s))


