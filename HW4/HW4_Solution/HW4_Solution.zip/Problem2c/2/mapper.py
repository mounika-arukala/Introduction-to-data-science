#!/usr/bin/env python
import sys
import re
for i in sys.stdin:
	for j in open('ref1'):
		col1,col3=i.split()
		col4,col6=j.split()
		if col1==col4:
			if(int(col6)>1.5*int(col3)):
				print("%s"%(col1[3:6]))
			break
	
	
