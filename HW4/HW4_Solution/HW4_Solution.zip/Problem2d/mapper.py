#!/usr/bin/env python

import sys
import re
s=1
for i in sys.stdin:
	for j in open('ref'):
		col1,col2,col3=i.split()
		col4,col5,col6=j.split()
		if col1==col4 and col2==col5:
			print("%s\t%s\t%d"%(col3,col6,s))
			break

	
	
