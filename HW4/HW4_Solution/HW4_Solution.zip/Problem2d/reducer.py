#!/usr/bin/env python 
import sys
c = 0, c1 = 0, c2 = 0, c3 = 0, c4 = 0, c5 = 0, c6 = 0, c7 = 0
change = ""

for i in sys.stdin:
   i = i.strip()
   col1,col2,value = i.split()
   value = int(value)
 
   if col1 != col2:	
	c = c+value
	if int(col1) == 1:
		if int(col2) == 2:
			c1=c1+value
		elif int(col2) == 3:
			c2=c2+value
	elif int(col1) == 2:
		if int(col2) == 1:
			c3=c3+value
		elif int(col2) == 3:
			c4=c4+value
	elif int(col1) == 3:
		if int(col2) == 1:
			c5=c5+value
		elif int(col2) == 2:
			c6=c6+value

print c
if c1>c7:
	c7=c1
	change = "1-2"
if c2>c7:
	c7=c2
	change = "1-3"
if c3>c7:
	c7=c3
	change = "2-1"
if c4>c7:
	c7=c4
	change = "2-3"
if c5>c7:
	c7=c5
	change = "3-1"
if c6>c7:
	c7=c6
	change = "3-2"
print ("The most common type of change is %s and it is %s times"%(change,c7))
